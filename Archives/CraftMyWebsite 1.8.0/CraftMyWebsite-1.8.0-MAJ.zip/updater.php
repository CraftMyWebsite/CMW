<?php 
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
//error_reporting(0);
require_once('controleur/config.php');
require_once('controleur/connection_base.php');

if(isset($_POST['go']) AND $_POST['go'] == 1)
{
	//Modifcation des fichiers
	$archiveUpdate = new ZipArchive;
	if($archiveUpdate->open('update.zip') === TRUE)
	{
		$archiveUpdate->extractTo(__DIR__);
		$archiveUpdate->close();

		vote17to18($bddConnection);
		grade17to18($bddConnection);
		accueil17to18();
		config17to18();
		bdd17to18($bddConnection);
		format17to18($bddConnection);
		serveur17to18($bddConnection);
		file17to18();

		unlink('update.zip');
		echo 'Mise à jour réussie ! <a href="index.php?&removeUpdater=true">Aller sur votre site</a>';
	}
}
else
{
	?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="CraftMyWebsite">
    <link rel="stylesheet" href="https://getbootstrap.com/docs/4.4/dist/css/bootstrap.min.css">
    <style>
        .bg-light2 {
            background-color: rgb(240, 240, 240) !important;
        }

        .container {
            max-width: 960px;
        }
    </style>
    <title>CraftMyWebsite | Mise à jour - 1.8</title>
</head>

<body class="bg-light2">

    <div class="container">

        <div class="pt-5 text-center">
            <img class="d-block mx-auto mb-4 img"
            src="https://cdn.discordapp.com/attachments/382840368099753984/775433866777198622/craftmywebsite.png" alt="CraftMyWebsite - Logo" width="94"
            height="94" style="border-radius: 9px;">
            <h2>Mise à jour de votre site ! 😃</h2>
            <p class="lead">
                Bienvenue sur la page de mise à jour de votre site internet<br />
            </p>
            <div class="alert alert-danger">
                <p class="text">
                    Attention: la mise à jour de votre site web et irréversible ! Pensez à sauvegarder vos fichiers et
                    bases
                    de données avant de procéder à celle-ci.
                </p>
            </div>
            <hr/>
            <div class="alert alert-warning alert-dismissible">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <p class="text">
                    Cette version réinitialisera votre choix thème (Défault), les thèmes autre que Default sont pas forcément compatible avec cette version - en cas de doute contacter le créateur du thème que vous souaither utilisé ! 
                </p>
            </div>
            <div class="block border" style="border-radius: 2% !important;">

                <div class="row p-5">
                    <div class="col-md-12">


                        <div class="accordion" id="accordionExample">

                            <h2 class="mb-3">
                                <button class="btn btn-block btn-primary" type="button" data-toggle="collapse"
                                    data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Changlog
                                </button>
                            </h2>
                            <div id="collapseOne" class="collapse bg-light" aria-labelledby="headingOne"
                                data-parent="#accordionExample" style="margin:0px;">
                                <div class="card-body">
                                    <div style="max-height: 300px !important;overflow-y: scroll !important;">
                                        <div class="container-fluid">

                                            <p class="card-text" style="text-align: justify;">

                                                Ajouts ([+]), modifications ([=]) et suppressions ([-])
                                                (|) Bugs Fix<br/>
                                                <br>

                                                [+] : Ajouter un événement (envoyé sur le serveur) qui rappelle au
                                                joueur de
                                                voter</br>
                                                [=] : Sur le panel administrateur, rubrique membre, plusieurs pages pour
                                                l'affichage des membres avec fonctionnalités de recherche/tri</br>
                                                (|) : Possibilité de modifier les quantités dans la boutique</br>
                                                [=] : Refonte de la structure de la page profil</br>
                                                [=] : Possibilité de se désabonner de la Newsletter en 1 clic</br>
                                                [=] : Confirmation lors d'une tentative de suppression d'un compte
                                                joueur</br>
                                                [+] : Ajout du moyen de paiement PaysafeCard mais par validation
                                                manuelle
                                                par l'administrateur du site</br>
                                                [=] : Refonte du système de permission</br>
                                                [+] : Mise en place d'une fonction unique permettant de vérifier les
                                                permissions d'un joueur</br>
                                                [=] : Refonte du panel administrateur</br>
                                                [-] : Retrait de Paypal Business car il n'est plus fonctionnel</br>
                                                (|) : Réglage bug visuel sur le modal d'inscription</br>
                                                (|) : Fix bug d'impossibilité d'édition des membres s'il y'en a plus de
                                                100</br>
                                                [=] : Refonte de la page membres dans le panel administrateur</br>
                                                [=] : Réunion de deux fonctions JSONAPI équivalentes</br>
                                                [=] : Refonte du système de gestion des serveurs RCON, Query et
                                                JSONAPI</br>
                                                [=] : Refonte du système de requête et de cache pour les serveurs RCON,
                                                Query et JSONAPI</br>
                                                [=] : Refonte de la page de gestion des serveurs RCON, Query et
                                                JSONAPI</br>
                                                [=] : Réglage du chargement des skins</br>
                                                [=] : Refonte de l'éditeur de page personnalisée</br>
                                                [=] : Déplacement du système de cache des images de skin des
                                                utilisateurs
                                                vers le répertoire/utilisateurs prévu à cet effet</br>
                                                [=] : Refonte totale de l'installateur</br>
                                                (|) : Remise en place de la fonction de suppression du dossier
                                                d'installation</br>
                                                [=] : Amélioration de la fonction récursive pour les chmod
                                                automatique</br>
                                                [+] : Ajout de l'affichage de plusieurs informations de base sur
                                                l'installateur</br>
                                                [=] : Réglages d'incohérences graphique sur le panel administrateur</br>
                                                (|) : Réglage de bug sur la page de chat instantanné avec le serveur
                                                depuis
                                                le site</br>
                                                [=] : Refonte du système de stats sur le panel administrateur</br>
                                                (|) : Fix d'un bug qui ne prenait pas en compte le choix de la
                                                Newsletter à
                                                l'inscription</br>
                                                [=] : L'exemple d'IP pour les serveurs JSONAPI est désormais en chiffre
                                                comme le demande le système</br>
                                                (|) : Fix erreur 500 à la récupération du mot de passe par email</br>
                                                [+] : Ajout des têtes des joueurs en ligne sur la page chat</br>
                                                [=] : Refonte de la page vote</br>
                                                [+] : Ajout sur la page vote de pouvoir envoyer plusieurs récompenses
                                                avec
                                                pourcentage de l'obtenir</br>
                                                [+] : Ajout d'une toplist sur la page de vote</br>
                                                (|) : Fix d'un bug qui permettait de se give des jetons</br>
                                                [+] : Nouveau Thème défaut</br>
                                                [+] : Ajout d'un éditeur de texte complet</br>
                                                [+] : Option pour les images sur l'éditeur de texte</br>
                                                [+] : Ajout d'une information Hors-Ligne/En ligne au niveau de RCON et
                                                JSONAPI</br>
                                                [+] : Pouvoir citer une réponse sur le forum</br>
                                                [+] : Barre de recherche sur le forum</br>
                                                [=] : Heure sur les réponses du forum</br>
                                                [+] : Ajout d'un mode nuit sur le panel</br>
                                                [+] : Ajout d'une option pour acheter une offre avant une autre sur la
                                                boutique</br>
                                                [=] : Amélioration de l'éditeur des offres sur la boutique</br>
                                                [-] : Suppression de la messagerie qui n'est pas utilisée</br>
                                                [=] : Corrections orthographiques et de tournures de phrases<br /></br>


                                                Contributeurs : PandaxCSGO, Guedesite, PinglsDzn, BadiiiX, Emilien52,
                                                Florentlife, X3RO, RedBoard, AnackKel, Amjido.

                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <form action="" method="post">
                                <input type="hidden" name="go" value="1">
                                <button type="submit" class="btn btn-success btn-block">Mettre à jour le CMS (irréversible)</button>
                              </form>
                        </div>


                    </div>
                </div>

            </div>



        </div>

    </div>

    <footer class="my-4 text-muted text-center text-small">
        <p class="mb-1">&copy; 2014 - <script>
                document.write(new Date().getFullYear())
            </script> CraftMyWebsite</p>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="https://craftmywebsite.fr/forum/index.php" target="_blank">Forum</a>
            </li>
            <li class="list-inline-item"><a href="https://discord.gg/P94b7d5" target="_blank"> <i
                        class="fab fa-discord"></i> Discord</a></li>
            <li class="list-inline-item"><a href="https://github.com/CraftMyWebsite" target="_blank"> <i
                        class="fab fa-github"></i> GitHub</a></li>
        </ul>
    </footer>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>

</html>  
 
	<?php
}


// https://github.com/guedesite/CMWListDeleteFile
function file17to18() {
	unlink('admin\actions\addSmiley.php');
	unlink('admin\actions\boutique.php');
	unlink('admin\actions\getBoutiqueListe.php');
	unlink('admin\actions\nom.php');
	unlink('admin\actions\nomJoueur.php');
	unlink('admin\actions\supprSmiley.php');
	undir('admin\assets\css\page');
	undir('admin\assets\css\plugins');
	unlink('admin\assets\css\admin-style.css');
	unlink('admin\assets\css\forum.css');
	undir('admin\assets\fonts');
	undir('admin\assets\img');
	undir('admin\assets\js\Chart');
	undir('admin\assets\js\plugins\dataTables');
	undir('admin\assets\js\plugins\flot');
	undir('admin\assets\js\plugins\metisMenu');
	undir('admin\assets\js\plugins\morris');
	undir('admin\assets\js\tinymce');
	unlink('admin\assets\js\bootstrap.min.js');
	undir('admin\assets\less');
	undir('admin\assets\sound');
	unlink('admin\donnees\regServeur.php');
	unlink('admin\include\donneescustom.php');
	unlink('admin\include\header.php');
	unlink('admin\include\index.php');
	unlink('admin\include\pagegen.php');
	unlink('admin\include\sidebar.php');
	undir('admin\page');
	unlink('admin\donnees.php');
	unlink('controleur\app\groupsList.php');
	undir('controleur\grades');
	undir('controleur\json');
	undir('controleur\messagerie');
	unlink('controleur\support\supprInstall.php');
	unlink('controleur\notifications.php');
	undir('include\ckeditor');
	undir('include\MinecraftAvatar');
	undir('include\SkinApi');
	unlink('modele\app\messagerie.class.php');
	unlink('modele\config\configServeur.yml');
	unlink('modele\forum\miseEnPage.php');
	undir('modele\grades\NOT_TOUCH');
	undir('modele\grades');
	undir('theme\default\css');
	undir('theme\default\fonts');
	undir('theme\default\img');
	undir('theme\default\js');
	unlink('theme\default\pages\index.php');
	unlink('theme\default\pages\messagerie.php');
	undir('theme\default\plugins\preloader\css');
	undir('theme\default\plugins\preloader\img');
	unlink('theme\default\section_gauche.php');
	undir('theme\smileys');

}

function serveur17to18($bddConnection) {
	$serv = new Lire('modele/config/configServeur.yml');
  	$serv = $serv->GetTableau();

  	if(isset($serv['Json'])) {
  		foreach($serv['Json'] as $value)
		{
			unset($Infos);
			if($infos['localhost']) {
				$infos['adresse'] = "localhost";
			} else {
				$infos['adresse'] = $value['adresse'];
			}
			if(!isset($value['port']['query']))
			{
				$infos['port'] = $value['port'];
				$infos['user'] = $value['utilisateur'];
				$infos['protocole'] = 0; 
			}
			else
			{
				$infos['protocole'] = 1; 
				$infos['rcon'] = $value['port']['rcon'];
				$infos['query'] = $value['port']['query'];
			}
			$infos['mdp'] = $value['mdp'];
			$infos['nom'] = $value['nom'];
			if($infos['protocole'] == 0)
			{
				$req = $bddConnection->prepare('INSERT INTO cmw_serveur (nom, adresse, protocole, port, utilisateur, mdp) VALUES (:nom, :adresse, :protocole, :port, :utilisateur, :mdp)');
			}
			else
			{
				$req = $bddConnection->prepare('INSERT INTO cmw_serveur (nom, adresse, protocole, port, port2, mdp) VALUES (:nom, :adresse, :protocole, :query, :rcon, :mdp)');
			}
			$req->execute($infos);
		}	
  	}
}

function format17to18($bddConnection) {

	$BbToCk=array(
	    "[b]"  => "<b>",
	    "[/b]"  => "</b>",
	    "[i]"  => "<i>",
	    "[/i]"  => "</i>",
	    "[u]"  => "<u>",
	    "[/u]"  => "</u>",
	    "[s]"  => "<s>",
	    "[/s]"  => "</s>",
	    "[left]"  => "<div style='text-align:left;'>",
	    "[/left]"  => "</div>",
	    "[center]"  => "<center>",
	    "[center]"  => "</center>",
	    "[right]"  => "<div style='text-align:right;'>",
	    "[/right]"  => "</div>",
	    "[justify]"  => "<div style='text-align:justify;'>",
	    "[/justify]"  => "</div>",
	    "[url]"  => "<a href='",
	    "[/url]"  => "'>lien</a>",
	    "[img]"  => "<img src='",
	    "[/img]"  => "' />"
	);

	$bb = $bddConnection->query('SELECT contenue, id FROM cmw_forum_answer WHERE 1');
	$bb = $bb->fetchAll(PDO::FETCH_ASSOC);
	foreach($bb as $cont)
	{
		$str = $cont['contenue'];
		foreach($BbToCk as $key => $value) {
			$str = str_replace($key, $value, $str);
		}
		$req = $bddConnection->prepare("UPDATE cmw_forum_answer SET contenue=:cont WHERE id=:id");
		$req->execute(array( 
			'id' => $cont['id'],
			'cont' => $str
		));
	}

	$bb = $bddConnection->query('SELECT contenue, id FROM cmw_forum_post WHERE 1');
	$bb = $bb->fetchAll(PDO::FETCH_ASSOC);
	foreach($bb as $cont)
	{
		$str = $cont['contenue'];
		foreach($BbToCk as $key => $value) {
			$str = str_replace($key, $value, $str);
		}
		$req = $bddConnection->prepare("UPDATE cmw_forum_post SET contenue=:cont WHERE id=:id");
		$req->execute(array( 
			'id' => $cont['id'],
			'cont' => $str
		));
	}

	$bb = $bddConnection->query('SELECT message, id FROM cmw_support WHERE 1');
	$bb = $bb->fetchAll(PDO::FETCH_ASSOC);
	foreach($bb as $cont)
	{
		$str = $cont['message'];
		foreach($BbToCk as $key => $value) {
			$str = str_replace($key, $value, $str);
		}
		$req = $bddConnection->prepare("UPDATE cmw_support SET message=:cont WHERE id=:id");
		$req->execute(array( 
			'id' => $cont['id'],
			'cont' => $str
		));
	}

	$bb = $bddConnection->query('SELECT message, id FROM cmw_support_commentaires WHERE 1');
	$bb = $bb->fetchAll(PDO::FETCH_ASSOC);
	foreach($bb as $cont)
	{
		$str = $cont['message'];
		foreach($BbToCk as $key => $value) {
			$str = str_replace($key, $value, $str);
		}
		$req = $bddConnection->prepare("UPDATE cmw_support_commentaires SET message=:cont WHERE id=:id");
		$req->execute(array( 
			'id' => $cont['id'],
			'cont' => $str
		));
	}

}
function bdd17to18($bddConnection) {
	$bddConnection->exec("ALTER TABLE cmw_boutique_categories ADD `showNumber` int(1) NOT NULL");
	$req = $bddConnection->prepare("UPDATE cmw_boutique_action SET showNumber=:s WHERE 1");
	$req->execute(array( 
		's' => 4
	));

	$bddConnection->exec("ALTER TABLE cmw_boutique_offres MODIFY COLUMN evo text NULL");
	$bddConnection->exec("ALTER TABLE cmw_boutique_offres ADD max_vente int(11) NOT NULL");
	$req = $bddConnection->prepare("UPDATE cmw_boutique_offres SET max_vente=:s WHERE 1");
	$req->execute(array( 
		's' => -1
	));

	$bddConnection->exec("ALTER TABLE cmw_boutique_stats MODIFY COLUMN date_achat datetime NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_dedipass MODIFY COLUMN date_achat datetime NOT NULL");

	$bddConnection->exec("ALTER TABLE cmw_forum_answer MODIFY COLUMN date_post datetime NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_forum_answer MODIFY COLUMN d_edition datetime DEFAULT NULL");

	$bddConnection->exec("ALTER TABLE cmw_forum_answer_removed MODIFY COLUMN date_creation datetime DEFAULT NULL");
	$bddConnection->exec("ALTER TABLE cmw_forum_answer_removed MODIFY COLUMN date_suppression datetime NOT NULL");

	$bddConnection->exec("ALTER TABLE cmw_forum_post MODIFY COLUMN date_creation datetime NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_forum_post MODIFY COLUMN d_edition datetime DEFAULT NULL");

	$bddConnection->exec("DROP TABLE cmw_forum_smileys");

	$bddConnection->exec("ALTER TABLE cmw_forum_topic_removed ALTER COLUM date_creation datetime NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_forum_topic_removed ALTER COLUM date_suppression datetime NOT NULL");

	$bddConnection->exec("ALTER TABLE cmw_maintenance ADD maintenanceMsgInscr text NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_maintenance ADD inscription tinyint(1) UNSIGNED NOT NULL DEFAULT '0'");

	$bddConnection->exec("DROP TABLE cmw_messages");

	$bddConnection->exec("ALTER TABLE cmw_tempgrades ADD PRIMARY KEY (id)");

	$bddConnection->exec("ALTER TABLE cmw_users ALTER COLUM email varchar(64) NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_users ALTER COLUM img_extension char(4) NULL");
	$bddConnection->exec("ALTER TABLE cmw_users ADD achats text NULL");

	$bddConnection->exec("ALTER TABLE cmw_visits MODIFY COLUMN dates datetime NOT NULL");

	$bddConnection->exec("ALTER TABLE cmw_votes MODIFY COLUMN pseudo varchar(50) NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_votes ADD ip varchar(20) NOT NULL");
	$bddConnection->exec("ALTER TABLE cmw_votes ADD isOld int(1) DEFAULT 0");

	$bddConnection->exec("ALTER TABLE cmw_votes_temp DROP COLUMN methode");
	$bddConnection->exec("ALTER TABLE cmw_votes_temp MODIFY COLUMN action text NOT NULL");

	$bddConnection->exec("ALTER TABLE cmw_votes_recompense_auto_config DROP COLUMN message");
	$bddConnection->exec("ALTER TABLE cmw_votes_recompense_auto_config DROP COLUMN serveur");
	$bddConnection->exec("ALTER TABLE cmw_votes_recompense_auto_config DROP COLUMN commande");
	$bddConnection->exec("ALTER TABLE cmw_votes_recompense_auto_config ADD action text NULL");

	$bddConnection->exec("CREATE TABLE IF NOT EXISTS cmw_serveur (
	  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	  nom VARCHAR(32) NOT NULL,
	  adresse CHAR(15) NOT NULL,
	  protocole BOOLEAN NOT NULL DEFAULT 0,
	  port SMALLINT UNSIGNED NOT NULL,
	  port2 SMALLINT UNSIGNED NULL,
	  utilisateur VARCHAR(32) NULL,
	  mdp VARCHAR(64) NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;
	
	CREATE TABLE cmw_paysafecard_offres (
	  id smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	  montant text NOT NULL,
	  jetons varchar(32) NOT NULL,
	  description text NOT NULL,
	  statut tinyint(1) NOT NULL DEFAULT '1'
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	CREATE TABLE cmw_paysafecard_historique (
	  id smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	  pseudo varchar(32) NOT NULL,
	  code char(16) NOT NULL,
	  offre smallint(5) UNSIGNED NOT NULL,
	  statut tinyint(1) NOT NULL DEFAULT '0',
	  CONSTRAINT cle_offre 
	  FOREIGN KEY (offre) 
	  REFERENCES cmw_paysafecard_offres(id)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	CREATE TABLE IF NOT EXISTS `cmw_paypal_historique` (
	  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
	  `montant` double(5, 2) UNSIGNED NOT NULL,
	  `pseudo` varchar(32) NOT NULL,
	  `date` datetime NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;

	CREATE TABLE cmw_grades (
	  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	  nom VARCHAR(200) NOT NULL,
	  priorite INT UNSIGNED NOT NULL DEFAULT 0,
	  prefix CHAR(9) NOT NULL DEFAULT '',
	  couleur CHAR(9) NOT NULL DEFAULT '',
	  effets VARCHAR(64) NOT NULL DEFAULT '',
	  permDefault BLOB,
	  permPanel LONGBLOB, 
	  permForum BLOB
	)              
	ENGINE= INNODB;

	ALTER TABLE cmw_grades AUTO_INCREMENT=2;

	ALTER TABLE cmw_users ADD CONSTRAINT cle_grade FOREIGN KEY (rang) REFERENCES cmw_grades(id);

	INSERT INTO `cmw_paysafecard_offres` (`id`, `montant`, `jetons`, `description`, `statut`) VALUES
	(1, '10', '100', 'Offre 10€ = 10 jetons', 1),
	(2, '25', '25', 'Offre 25€ = 25 jetons', 1),
	(3, '50', '50', 'Offre 50€ = 50 jetons', 1);");
}

function config17to18() {
	$lecture = new Lire('modele/config/config.yml');
  	$lecture = $lecture->GetTableau();
  	$lecture['vote']['maxDisplay'] = 10;
  	$lecture['General']['moneyName'] = "Jeton";
  	$lecture['General']['createur']['couleur'] = "#ffffff";
  	$lecture['General']['createur']['bg'] = "#b83d3d";
	$ecriture = new Ecrire('modele/config/config.yml', $lecture);
}
function accueil17to18() {
	$lectureAccueil = new Lire('modele/config/accueil.yml');
  	$lectureAccueil = $lectureAccueil->GetTableau();

  	foreach($lectureAccueil['Infos'] as $key => $value) {
  		if(!isset($lectureAccueil['Infos'][$key]['type'])) {
  			$lectureAccueil['Infos'][$key]['type'] = startsWith($lectureAccueil['Infos'][$key]['lien'], '?page=') ? 'page' : 'lien';
  		}
  	}
	$ecriture = new Ecrire('modele/config/accueil.yml', $lectureAccueil);
}

function grade17to18($bddConnection) {

	$dirGrades = 'modele/grades/';
	$initGrades = glob($dirGrades.'*.yml');

	$lastGrade[] = array();
	foreach($initGrades as $numGrade) {
	    $lastGrade[] = substr($numGrade, 16, -4);
	}

	$lastGrade = array_filter($lastGrade);
	if(empty($lastGrade))
	    array_push($lastGrade, -1);

	for($i = 2;$i <= max($lastGrade); $i++) {
	    $perms = Permission::getInstance()->readPerm($i);
	    $data = array();
	    $data['nom'] = $perms['Grade'];
	    $data['priorite'] = $i;
	    $data['prefix'] = $perms['prefix'];
	    $data['couleur'] = $perms['couleur'];
	    $data['effets'] = $perms['effets'];
	    $data['permDefault'] = serialize($perms['PermsDefault']);
	    $data['permPanel'] = serialize($perms['PermsPanel']);
	    $data['permForum'] = serialize($perms['PermsForum']);
	    $update = $bddConnection->prepare('INSERT INTO cmw_grades (nom, priorite, prefix, couleur, effets, permDefault, permPanel, permForum) VALUES (:nom, :priorite, :prefix, :couleur, :effets, :permDefault, :permPanel, :permForum)');
	    $update->execute($data); 
	}
}

function vote17to18($bddConnection) {
	$oldvote = $bddConnection->query('SELECT * FROM cmw_votes_config WHERE 1');
	$oldvote = $oldvote->fetchAll(PDO::FETCH_ASSOC);

	$bddConnection->exec('ALTER TABLE cmw_votes_config DROP COLUMN message');
	$bddConnection->exec('ALTER TABLE cmw_votes_config DROP COLUMN methode');
	$bddConnection->exec('ALTER TABLE cmw_votes_config MODIFY COLUMN action text null');

	foreach($oldvote as $lectureVotes)
	{
		$i = 0;
		$final = array();
		$action = explode(':', $lectureVotes['action'], 2);
		if($action[0] == "give")
		{
			$action = explode(':', $action[1]);
			$final[$i]['type'] = "item";
			$final[$i]['value'] = $action[1];
			$final[$i]['value2'] = $action[3];
			$final[$i]['methode'] = $lectureVotes['methode'];
			$final[$i]['pourcentage'] = 100;
		}
		else if($action[0] == "jeton")
		{
			$final[$i]['type'] = "jeton";
			$final[$i]['value'] = $action[1];
			$final[$i]['pourcentage'] = 100;
		}
		else
		{
			$final[$i]['type'] = "commande";
			$final[$i]['value'] = $action[1];
			$final[$i]['methode'] = $lectureVotes['methode'];
			$final[$i]['pourcentage'] = 100;
		}
		if(!empty($lectureVotes['message']))
		{
			$i++;
			$final[$i]['type'] = "message";
			$final[$i]['value'] = $lectureVotes['message'];
			$final[$i]['methode'] = 1;
			$final[$i]['pourcentage'] = 100;
		}
		if(!empty($final)) {
			$req = $bddConnection->prepare('UPDATE cmw_votes_config SET action = :action WHERE id = :id');
			$req->execute(array(
				'action' => json_encode(array_values($final)),
				'id' =>  $lectureVotes['id'],
				));
		}
	}
}
function startsWith ($string, $startString) 
{ 
    $len = strlen($startString); 
    return (substr($string, 0, $len) === $startString); 
} 

function undir($dir) {
   if (is_dir($dir)) {
     $objects = scandir($dir);
     foreach ($objects as $object) {
       if ($object != "." && $object != "..") {
         if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object);
       }
     }
     reset($objects);
     rmdir($dir);
   }
 }