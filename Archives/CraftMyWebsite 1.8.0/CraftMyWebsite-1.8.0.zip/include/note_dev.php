<?php
$notedevdistant = file_get_contents('http://craftmywebsite.fr/release/note.txt');
echo $notedevdistant;
?>

Contributeurs:

1.6.x: Lucerno, DogeMVP, SawnFx, Cersus et TheTueurCity

1.7.0: Florentlife, Oxykis et Ethanox

1.7.1: Florentlife et Emilien52

1.7.2: Ethanox, PinglsDzn, Emilien52, Mario359, Guedesite et Florentlife

1.7.3: Emilien52, Guedesite, BadiiiiX et Florentlife

1.8.0: Guedesite, PinglsDzn, Emilien52, BadiiiX, Pandax et Florentlife
