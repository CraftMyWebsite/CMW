  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="robots" content="nofollow, noindex">
  <meta name="author" content="CraftMyWebsite">

  <link rel="stylesheet" href="https://getbootstrap.com/docs/4.4/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app/ressources/css/main.css">
  <title>CraftMyWebsite | Installation - Etape 1</title>
  <script type="text/javascript">
			(function titleScroller(text) {
				document.title = text;
				setTimeout(function () {
					titleScroller(text.substr(1) + text.substr(0, 1));
				}, 500);
			}("CraftMyWebsite | Installation - Etape <?php echo $installEtape; ?> </> "));
		</script>

  <meta name="theme-color" content="#007BFF">
  <meta name="msapplication-navbutton-color" content="#007BFF">
  <meta name="apple-mobile-web-app-statut-bar-style" content="#007BFF">
  <meta name="apple-mobile-web-app-capable" content="#007BFF">
