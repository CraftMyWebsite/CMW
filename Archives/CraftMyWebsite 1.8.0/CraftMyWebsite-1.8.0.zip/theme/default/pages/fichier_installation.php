<section id="Installation">

    <div class="container-fluid col-md-12 col-lg-9 col-sm-10">
        <div class="row mt-5">

            <div class="container-fluid col-md-12 col-lg-9 col-sm-10">
                <div class="alert alert-danger" role="alert">

                    <h4 class="alert-heading text-uppercase pt-1"><i class="fas fa-exclamation-triangle"></i> Dossier <b>Installation</b> non supprimé !</h4>
                    <hr>
                    <h5>
                        <b>Erreur :</b> Pour des questions de sécurité, avant d'utiliser votre site web, nous vous demandons de supprimer immédiatement votre dossier nommé <b>Installation</b> !

                        <hr>

                        <small class="">Une fois supprimé, vous pouvez rafaîchir la page pour ne plus voir ce message !</small>
                    </h5>

                </div>
            </div>

        </div>
    </div>

</section>