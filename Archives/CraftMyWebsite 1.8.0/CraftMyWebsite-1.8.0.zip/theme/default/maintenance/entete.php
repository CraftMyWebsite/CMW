<div class="alert alert-danger" style="text-align: center;border-radius: 0px;margin-bottom: 0px;">
  <span class="fa fa-exclamation-triangle" aria-hidden="true"></span> Le mode maintenance a été activé, seuls les administrateurs ont accès au site internet !
</div>