<?php

namespace xPaw;

class MinecraftQueryException extends \Exception
{
	// Exception thrown by MinecraftQuery class
}
