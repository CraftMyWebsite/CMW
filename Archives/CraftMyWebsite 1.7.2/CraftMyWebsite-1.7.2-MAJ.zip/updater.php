<?php 
error_reporting(0);
require_once('controleur/config.php');
require_once('controleur/connection_base.php');

if(isset($_POST['go']) AND $_POST['go'] == 1)
{
	//Modification des donnees
	$temp = $_Serveur_;
	unset($temp['Payement']['mcgpass']);
	unset($temp['Payement']['mcgpass_id']);
	unset($temp['Payement']['mcgpass_idSite']);
	//Verifier bug moche (admin/action/supprLienMenu.php)

	//Modifcation des fichiers
	$archiveUpdate = new ZipArchive;
	if($archiveUpdate->open('updater.zip') === TRUE)
	{
		$archiveUpdate->extractTo(__DIR__);
		$archiveUpdate->close();
		$ecriture = new Ecrire('modele/config/config.yml', $temp);
		//Modification de la base de donnée :
		$bddConnection->exec('DROP TABLE cmw_mcgpass;');
		$bddConnection->exec('CREATE TABLE IF NOT EXISTS `cmw_cache_json` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `requete` varchar(255) NOT NULL,
  `valeur`TEXT NOT NULL,
  `temp`int(11)
) ENGINE= InnoDB;');
		$bddConnection->exec('ALTER TABLE cmw_votes_config ADD idCustom INT NOT NULL DEFAULT -1');
		unlink('update.zip');
		rrmdir("admin/assets/css/font-awesome");
		unlink("controleur/mcgpass.php");
		unlink("modele/alloconv.class.php");
		rrmdir("controleur/perms");
		rrmdir("modele/perms");
		echo 'SUPPRIMER LE FICHIER UPDATER.PHP !!!! <a href="index.php">Aller sur votre site</a>';
	}
}
else
{
	?><form action="" method="post">
		<h1>Patch de CraftMyWebsite : 1.7.1 -> 1.7.2</h1>
		<p>Attention: si vous n'êtes pas sur de vous, effectuer une réinstallation totale</p>
		<center><h3>BONNE INSTALLATION :D</h3></center>
		<input type="hidden" name="go" value="1">
		<button type="submit">Effectuer l'installation</button>
		<a href="index.php">Ne pas effectuer l'update. (vous devrez supprimer les fichiers par sécurité !)</a>
	</form>
	<?php
}
function rrmdir($dir) {
   if (is_dir($dir)) {
     $objects = scandir($dir);
     foreach ($objects as $object) {
       if ($object != "." && $object != "..") {
         if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object);
       }
     }
     reset($objects);
     rmdir($dir);
   }
 }