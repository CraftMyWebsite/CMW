<?php
$versioncms = "1.8.3";
$displayversioncms = "<span versioncms>".$versioncms."</span>";
?>
