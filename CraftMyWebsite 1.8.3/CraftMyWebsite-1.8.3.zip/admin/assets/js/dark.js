$('#darkSwitch').change(function(){
  $('#darkForm').submit();
});