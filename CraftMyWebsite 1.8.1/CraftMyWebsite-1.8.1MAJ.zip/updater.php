<?php 
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
//error_reporting(0);
require_once('controleur/config.php');
require_once('controleur/connection_base.php');

if(isset($_POST['go']) AND $_POST['go'] == 1) {

	//Modifcation des fichiers
	$archiveUpdate = new ZipArchive;
	if($archiveUpdate->open('update.zip') === TRUE)
	{
		$archiveUpdate->extractTo(__DIR__);
		$archiveUpdate->close();

		unlink('update.zip');
		echo 'Mise à jour réussie ! <a href="index.php?&removeUpdater=true">Aller sur votre site</a>';
	}
}else { ?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="CraftMyWebsite">
    <link rel="stylesheet" href="https://getbootstrap.com/docs/4.4/dist/css/bootstrap.min.css">
    <style>
        .bg-light2 {
            background-color: rgb(240, 240, 240) !important;
        }

        .container {
            max-width: 960px;
        }
    </style>
    <title>CraftMyWebsite | Mise à jour - 1.8.1</title>
</head>

<body class="bg-light2">

    <div class="container">

        <div class="pt-5 text-center">
            <img class="d-block mx-auto mb-4 img"
            src="https://cdn.discordapp.com/attachments/382840368099753984/775433866777198622/craftmywebsite.png" alt="CraftMyWebsite - Logo" width="94"
            height="94" style="border-radius: 9px;">
            <h2>Mise à jour de votre site ! 😃</h2>
            <p class="lead">
                Bienvenue sur la page de mise à jour de votre site internet<br />
            </p>
            <div class="alert alert-danger">
                <p class="text">
                    Attention: la mise à jour de votre site web et irréversible ! Pensez à sauvegarder vos fichiers et
                    bases de données avant de procéder à celle-ci.
                </p>
            </div>

			<hr />

            <div class="block border" style="border-radius: 2% !important;">

                <div class="row p-5">
                    <div class="col-md-12">


                        <div class="accordion" id="accordionExample">

                            <h2 class="mb-3">
                                <button class="btn btn-block btn-primary" type="button" data-toggle="collapse"
                                    data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Changelog
                                </button>
                            </h2>
                            <div id="collapseOne" class="collapse bg-light" aria-labelledby="headingOne"
                                data-parent="#accordionExample" style="margin:0px;">
                                <div class="card-body">
                                    <div style="max-height: 300px !important;overflow-y: scroll !important;">
                                        <div class="container-fluid">

                                            <p class="card-text" style="text-align: justify;">

                                                Ajouts ([+]), modifications ([=]) et suppressions ([-])
                                                (|) Bugs Fix<br />
                                                <br>

                                                [=] : Correction d'une faille de sécurité mineure (XSS) <br>
                                                [=] : Amélioration graphique du thème default
                                                [=] : Améliortion des requêtes vers l'api craftmywebsite.fr <br>
                                                [=] : Amélioration de la sécurité du panier sur la boutique <br>
                                                [=] : Agrandissement de touts les modals <br>
                                                [=] : Amélioration de ckeditor <br>
                                                [|] : Fix des bugs sur la page vote (Erreurs d'envoi de récompenses) <br>
                                                [|] : Fix bug du système de reset automatique des votes <br>
                                                [|] : Fix des miniatures <br>
                                                [|] : Fix du fond de l'entête du site <br>
                                                [|] : Fix de l'ensemble des bugs et erreurs sur la boutique <br>
                                                [|] : Fix des bugs touchant à la modification du forum <br>
                                                [|] : Fix des bugs liés aux grades et de leurs permissions <br>
                                                [|] : Fix des commentaires sur les news qui ne fonctionnaient pas <br>
                                                [|] : Fix des disfonctionnements des notifications  <br>
                                                [|] : Fix disfonctionnements liés au tchat <br>
                                                [|] : Fix des réseaux sociaux et signature dans la partie "membres" du panel <br>
                                                [|] : Fix des erreurs sur la page paiement du panel <br>
                                                [+] : Ajout d'un messsage sur la page vote quand les récompenses ne sont pas données <br>
                                                [+] : Ajout messages de confirmation/erreur lors de l'upload d'une image sur le panel <br>
                                                [+] : Ajout retour après une action sur la page des récompenses auto <br><br>



                                                Contributeurs : Guedesite, BadiiiX, Emilien52, deadfire, RedBoard, Tomo, CapDRAKE, MrSheepSheep, Human1st.<br />


                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <form action="" method="post">
                                <input type="hidden" name="go" value="1">
                                <button type="submit" class="btn btn-success btn-block">Mettre à jour le CMS (irréversible)</button>
                              </form>
                        </div>


                    </div>
                </div>

            </div>



        </div>

    </div>

    <footer class="my-4 text-muted text-center text-small">
        <p class="mb-1">&copy; 2014 - <script>
                document.write(new Date().getFullYear())
            </script> CraftMyWebsite</p>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="https://craftmywebsite.fr/forum/index.php" target="_blank">Forum</a>
            </li>
            <li class="list-inline-item"><a href="https://discord.gg/P94b7d5" target="_blank"> <i
                        class="fab fa-discord"></i> Discord</a></li>
            <li class="list-inline-item"><a href="https://github.com/CraftMyWebsite" target="_blank"> <i
                        class="fab fa-github"></i> GitHub</a></li>
        </ul>
    </footer>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>

</html>  
 
<?php }

function undir($dir) {
   if (is_dir($dir)) {
     $objects = scandir($dir);
     foreach ($objects as $object) {
       if ($object != "." && $object != "..") {
         if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object);
       }
     }
     reset($objects);
     rmdir($dir);
   }
 }