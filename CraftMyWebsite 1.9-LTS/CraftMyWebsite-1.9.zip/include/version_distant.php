<?php
$versioncmsrelease = '2.0';