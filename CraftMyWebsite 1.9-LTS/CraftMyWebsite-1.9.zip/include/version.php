<?php
$versioncms = '1.9 - LTS';
$displayversioncms = "<span class='versioncms'>".$versioncms. '</span>';
?>