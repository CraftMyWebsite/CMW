<section id="CustomPage">
    <div class="container-fluid col-md-9 col-lg-9 col-sm-10">
        <div class="row">
            <div class="container-fluid col-md-9 col-lg-9 col-sm-10">
               <?php include($customPage); ?>
            </div>
        </div>

    </div>
</section>