<?php
$versioncms = "1.8.2";
$displayversioncms = "<span versioncms>".$versioncms."</span>";
?>
