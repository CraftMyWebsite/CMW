<h4 class="mb-3">
    <span class="text-muted">Fin d'installation !</span>
</h4>
<div class="card d-flex">
    <div class="card-header">
        Le CMS a été installé avec succès !
    </div>
    <div class="card-body">
        Vous pouvez maintenant aller sur votre site <i class="fas fa-grin-wink"></i>
    </div>
    <div class="card-footer">
        <a href="../index.php?action=supprInstall" class="btn btn-primary btn-lg btn-block minecrafter" target="_blank" rel="noopener noreferrer">Aller sur mon site <i class="far fa-arrow-alt-circle-right"></i></a>
    </div>
</div>