# CraftMyWebsite

## Qu'est ce que CraftMyWebsite ?

CraftMyWebsite est un CMS Minecraft 100% gratuit créé en 2014 (première version le 1er Décembre 2014).
Présent depuis maintenant 6ans sur internet, le projet open-source depuis le début est aujourd'hui toujours maintenu par des passionnés !
Profitez d'un site stable pour votre serveur minecraft en utilisant notre cms !

### Les fonctionalitées sur la version 1.8.2

-   Boutique supportant Dedipass/Paypal en validation automatique et Paysafecard en validation manuelle 
-   Des rangs temporaires (boutique et site)
-   Système de news
-   Votes avec récompenses et systèmes de vérifications intégrés !
-   Gestion multi-serveur grâce à JSONAPI et à RCON/Query
-   Ticket support
-   Forum complet !
-   Newsletter 
-   Vérifications des inscriptions automatisé
-   Mode maintenance (avec chrono + inscription)
-   Thèmes créé par la communauté
-   Services google implanté dans le cms (adsense ...)
-   Et pleins d'autres !

Une démo est disponible sur notre [site internet](http://demo.craftmywebsite.fr/).
Les thèmes sont téléchargeable depuis notre forum [site internet](https://craftmywebsite.fr/forum/index.php?resources/featured)

### Support, infos et communauté

Retrouvez nous sur :

-   Discord: https://discord.gg/tscRZCU
-   Forum: https://craftmywebsite.fr/forum/
-   Contact: https://craftmywebsite.fr/contactez/nous/
-   Twitter: https://twitter.com/CraftMyWebsite

### Note

Sur la branche Master vous trouverez la dernière version du cms, vous pouvez participer au développement du cms en proposant vos idées sur le forum ou sur le Git depuis les onglets "issues" et "Pull Request".
Il est conseillé de Pull les modifications souhaité dans la branche Développement.
La Branche Archive et un service de stockage de l'ensemble des versions que nous avons développé depuis la version 1.7.0

### Nos partenaires

-   [WebStrator.fr](WebStrator.fr): Hébergeur web
-   [MineStrator.com](MineStrator.com): Hébergeur de serveurs Minecraft
-   [Serveurs-minecraft.net](Serveurs-minecraft.net): Référencement de serveurs Minecraft

### Copyright

CraftMyWebsite de [Vladimir.K](http://craftmywebsite.fr/cmw-lastest-build.php) est mis à disposition selon les termes de la [licence Creative Commons Attribution - Pas d'Utilisation Commerciale - Pas de Modification 4.0 International](http://creativecommons.org/licenses/by-nc-nd/4.0/). Fondé(e) sur une œuvre à [https://craftmywebsite.fr/cmw-lastest-build.php](http://craftmywebsite.fr/cmw-lastest-build.php). Les autorisations au-delà du champ de cette licence peuvent être obtenues à [https://craftmywebsite.fr/cgu](https://craftmywebsite.fr/cgu/). 

Copyright © CraftMyWebsite 2014-2021 
