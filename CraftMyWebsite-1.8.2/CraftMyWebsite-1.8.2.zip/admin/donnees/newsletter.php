<?php 
$news = $bddConnection->query('SELECT * FROM cmw_users WHERE newsletter = 1');
?>